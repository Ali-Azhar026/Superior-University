from flask import Flask, render_template, request
import pandas as pd
from transformers import AutoTokenizer, AutoModel
import torch
import faiss
import numpy as np

app = Flask(__name__)

# Load dataset
df = pd.read_csv("dataset.csv")
questions = df['Question'].tolist()
answers = df['Answer'].tolist()

# Load MiniLM model
model_name = "sentence-transformers/all-MiniLM-L6-v2"
tokenizer = AutoTokenizer.from_pretrained(model_name)
model = AutoModel.from_pretrained(model_name)

def embed_text(text_list):
    inputs = tokenizer(text_list, padding=True, truncation=True, return_tensors='pt')
    with torch.no_grad():
        embeddings = model(**inputs).last_hidden_state.mean(dim=1)
    return embeddings.cpu().numpy()

# FAISS index
question_embeddings = embed_text(questions)
dimension = question_embeddings.shape[1]
index = faiss.IndexFlatL2(dimension)
index.add(question_embeddings)

# Flask route
@app.route("/", methods=["GET", "POST"])
def home():
    answers_list = []
    if request.method == "POST":
        query = request.form["query"]
        query_emb = embed_text([query])
        D, I = index.search(query_emb, k=3)  # top 3 matches
        for idx in I[0]:
            answers_list.append(answers[idx])
    return render_template("index.html", answers=answers_list)

if __name__ == "__main__":
    app.run(debug=True)
